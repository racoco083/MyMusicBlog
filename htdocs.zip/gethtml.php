<html>
<title>HTTP GET 방식</title>
<body>
<?php
	echo '<H1>' , $_GET['query'] , '</H1>';
	echo 'value = ' . $_GET['value'];
?>
</body>
</html>