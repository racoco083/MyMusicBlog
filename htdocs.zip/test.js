$(document).ready(function(){

	
	refreshreview();
	
	$("#refresh").click(refreshreview);
	$("#search").click(search);
	function search(){
		$.getJSON("listreviewjson.php",function(json){
			$.getJSON("getcurrentid.php",function(currentid){
			$(".review").remove();
			var useremail=document.myform.useremail.value;
			$.each(json.review, function(){
				if(useremail==this["email"]){
					var review = '<article class="review">\
					<div class="img_frame">\
						<img class="user_image" src="getpicture.php?reviewid=' +
							this["reviewid"] + '" alt="None Picture" />';
					review += '<div class="user_memo"><p>' + this["memo"] + '</p></div>';
					review += '<div class="user_info">';
					review += '<img class="user_thumbnail" src="userimage.php?email=' +
							this["email"] + '" alt="User Image"/>';
					review += '<div class="user_email">' + this["email"] + '</div>';
					review += '<div class="user_date">' + this["time"] + '</div>';
					review += '</div></div>';
					if(this["userid"]==currentid){
						review += '<div id="remove_review"><a href="removereview.php?reviewid=' +
							this["reviewid"] + '">리뷰 삭제</a></div>';
						review += '<div id="edit_review"><a href="editreviewform.php?reviewid=' +
							this["reviewid"] + '">리뷰 수정</a></div>';
					}
					review += '<section class="review_reply">';
					review += '<div id="write_reply"><a href="writereplyform.php?reviewid=' +
							this["reviewid"] + '">댓글 등록</a></div>';
			
					if(this.reply){
						$.each(this.reply, function(){
							var reply = '<article class="reply">';
							reply += '<div class="user_reply"><p>' + this["memo"] + '</p></div>';
							reply += '<div class="user_info">';
							reply += '<img class="user_thumbnail" src="userimage.php?email=' +
										this["email"] + '" alt="User Image"/>';
							reply += '<div class="user_email">' + this["email"] + '</div>';
							reply += '<div class="user_date">' + this["time"] + '</div>';
							reply += '</div>';
							reply += '</article>';
							
							review += reply;
						});
					}
					
					review += '</section>';
					review += '</article>';
					
					$(".model").append(review);
				}
			});
			});
		});
	}
	function refreshreview(){
		$.getJSON("listreviewjson.php",function(json){
			$.getJSON("getcurrentid.php",function(currentid){
			$(".review").remove();
			
			$.each(json.review, function(){
				var review = '<article class="review">\
				<div class="img_frame">\
					<img class="user_image" src="getpicture.php?reviewid=' +
						this["reviewid"] + '" alt="None Picture" />';
				review += '<div class="user_memo"><p>' + this["memo"] + '</p></div>';
				review += '<div class="user_info">';
				review += '<img class="user_thumbnail" src="userimage.php?email=' +
						this["email"] + '" alt="User Image"/>';
				review += '<div class="user_email">' + this["email"] + '</div>';
				review += '<div class="user_date">' + this["time"] + '</div>';
				review += '</div></div>';
				if(this["userid"]==currentid){
					review += '<div id="remove_review"><a href="removereview.php?reviewid=' +
						this["reviewid"] + '">리뷰 삭제</a></div>';
					review += '<div id="edit_review"><a href="editreviewform.php?reviewid=' +
						this["reviewid"] + '">리뷰 수정</a></div>';
				}
				review += '<section class="review_reply">';
				review += '<div id="write_reply"><a href="writereplyform.php?reviewid=' +
						this["reviewid"] + '">댓글 등록</a></div>';
		
				if(this.reply){
					$.each(this.reply, function(){
						var reply = '<article class="reply">';
						reply += '<div class="user_reply"><p>' + this["memo"] + '</p></div>';
						reply += '<div class="user_info">';
						reply += '<img class="user_thumbnail" src="userimage.php?email=' +
									this["email"] + '" alt="User Image"/>';
						reply += '<div class="user_email">' + this["email"] + '</div>';
						reply += '<div class="user_date">' + this["time"] + '</div>';
						reply += '</div>';
						reply += '</article>';
						
						review += reply;
					});
				}
				
				review += '</section>';
				review += '</article>';
				
				$(".model").append(review);
			});
			});
		});
	}
});