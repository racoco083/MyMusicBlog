<html>
<head>
	<title>노래 보기</title>
	<meta charset="utf-8"/>
</head>
<body>
<?php
	require_once('dbcon.php');
	
	$dbc = mysqli_connect($host, $user, $pass, $dbname)
						or die("Error Connecting to MySQL Server.");
	mysqli_query($dbc, 'set names utf8');
	
	$query = "select * from song";
	$result = mysqli_query($dbc, $query)
						or die("Error Querying database.");
	echo '<table border=1>';
	echo '<tr><th>NAME</th><th>SINGER</th><th>NUMBER</th><th>FAVORITE</th>';
	while($row = mysqli_fetch_assoc($result)){
		echo '<tr>';
		echo '<td>' . $row['name'] . '</td><td>' . $row['singer'] . '</td><td>' . $row['number']. '</td><td>' . $row['favorite'] . '</br>';
		echo '</tr>';
	}
	echo '</table>';
	mysqli_free_result($result);
	mysqli_close($dbc);
?>
</body>