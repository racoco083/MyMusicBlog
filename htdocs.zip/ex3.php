    <html><head><title>����3</title></head> 
    <body> 
    <?
    phpinfo() 
    ?> 
    </body> 
    </html>