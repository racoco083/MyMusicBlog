$(document).ready(function(){

	
	refreshreview();
	
	$("#refresh").click(refreshreview);
	
	function refreshreview(){
		$.getJSON("listreviewjson.php",function(json){
		
			$(".review").remove();
			alert(json.review.length);
			
			$.each(json.review, function(){
				var review = '<article class="review">\
				<div class="img_frame">\
					<img class="user_image" src="getpicture.php?reviewid=' +
						this["reviewid"] + '" alt="None Picture" />';
				review += '<div class="user_memo"><p>' + this["memo"] + '</p></div>';
				review += '<div class="user_info">';
				review += '<img class="user_thumbnail" src="userimage.php?email=' +
						this["email"] + '" alt="User Image"/>';
				review += '<div class="user_email">' + this["email"] + '</div>';
				review += '<div class="user_date">' + this["time"] + '</div>';
				review += '</div></div>';
				
				review += '<section class="review_reply">';
				review += '<div id="write_reply"><a href="writereplyform.php?reviewid=' +
						this["reviewid"] + '">댓글 등록</a></div>';
			
		
				if(this.reply){
					$.each(this.reply, function(){
						//alert(json.review.length);
						var reply = '<article class="reply">';
						reply += '<div class="user_reply"><p>' + this["memo"] + '</p></div>';
						reply += '<div class="user_info">';
						reply += '<img class="user_thumbnail" src="userimage.php?email=' +
									this["email"] + '" alt="User Image"/>';
						reply += '<div class="user_email">' + this["email"] + '</div>';
						reply += '<div class="user_date">' + this["time"] + '</div>';
						reply += '</div>';
						reply += '</article>';
						
						review += reply;
					});
				}
				review += '</section>';
				review += '</article>';
				
				$(".model").append(review);
			});
			
		});
	}
});