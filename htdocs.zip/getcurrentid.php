<?php
	header('Content-Type: application/json;charset=UTF-8');
	require_once('session.php');
	
	$currentid = $_SESSION['id'];
	
	echo json_encode($currentid);
?>