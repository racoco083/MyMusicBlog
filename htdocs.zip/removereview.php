<?php
	require_once("session.php");
?>
<!DOCTYPE html>
<html>
<head>
<title>리뷰 삭제 결과</title>
<meta charset="utf-8"/>
</head>
<body>
<?php
	require_once('dbcon.php');
	
	if(!isset($_SESSION['id'])){
		exit('<a href="melon.php">로그인 상태가 아닙니다. 홈으로</a></body></html>');
	}
	
	$dbc = mysqli_connect($host, $user, $pass, $dbname)
						or die("Error Connecting to MySQL Server.");
	mysqli_query($dbc, 'set names utf8');
	$reviewid = $_GET['reviewid'];
	$query = "delete from review where reviewid = $reviewid";
	mysqli_query($dbc, $query) or die("Error Querying database.");
	mysqli_close($dbc);

	echo "리뷰가 삭제되었습니다..<br/><br/>";
	echo '<a href="/melon.php">홈으로</a>';
?>
</body>
</html>