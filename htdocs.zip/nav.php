<nav>
	<ul id="nav" class="sf-menu">
		<li class="current-menu-item"><a href="melon.php">HOME</a></li>
		<?php
			if(!isset($_SESSION['id']))
				echo '<li><a href="loginform.php">LOGIN</a></li>';
			else
				echo '<li><a href="logout.php">LOGOUT</a></li>';
		?>
		<li><a href="signupform.php">SIGNUP</a></li>
		<li><a href="top10.php">TOP10</a></li>
		<li><a href="review.php">REVIEW</a></li>
	</ul>
	<div id="combo-holder"></div>
</nav>