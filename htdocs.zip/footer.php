<footer>
	<div class="wrapper">
		<div class="footer-bottom">
			<div class="left">Melon <a href="http://www.melon.com/index.htm">melon.com</a></div>
			<div class="right">
				<ul id="social-bar">
					<li><a href="http://www.facebook.com/pages/Ansimuz/224538697564461"  title="Become a fan" class="poshytip"><img src="img/social/facebook.png"  alt="Facebook" /></a></li>
					<li><a href="https://twitter.com/ansimuz" title="Follow my tweets" class="poshytip"><img src="img/social/twitter.png"  alt="twitter" /></a></li>
					<li><a href="https://plus.google.com/109030791898417339180/posts"  title="Add to the circle" class="poshytip"><img src="img/social/plus.png" alt="Google plus" /></a></li>
				</ul>
			</div>
		</div>
		
	</div>
</footer>