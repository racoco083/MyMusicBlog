<?php
	require_once("session.php");
?>
<!DOCTYPE html>
<html>
<head>
<title>리뷰 수정</title>
<meta charset="utf-8"/>
</head>
<body>
<?php
	if(!isset($_SESSION['id'])) {
		exit('<a href="melon.php">로그인 상태가 아닙니다. 홈으로</a></body></html>');
	}
?>
	<h1>리뷰 수정</h1>
	<form method="post" enctype="multipart/form-data" action="editreview.php">
		리뷰 메모:<br/>
		<textarea name="memo" cols="50" rows="10"></textarea>
		<br/>
		리뷰 이미지:<br/>
		<input type="file" name="picture"/>
		<input type="hidden" name="reviewid" value="<?php echo $_GET['reviewid']; ?>">
		<br/>
		<br/>
		<input type="submit" value="리뷰 수정"/>
	</form>
</body>
</html>