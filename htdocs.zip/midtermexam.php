<?php
	header("Content-Type: text/html; charset=UTF-8");
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8"/>
	<style>
		header {
			background: darkgray;
			color: white;
			text-align: center;
			padding: 15px;
			margin: 20px;
		}
		table {
			border-collapse: collapse;
			width: 100%;
		}
		th {
			background-color: darkgray;
			color: white;
		}
		td, th {
			border: 2px solid darkblue;
			padding: 8px;
		}
		tr:nth-child(odd) {
			background-color: #eeeeee;
		}
	</style>
</head>
<body>
<header>
	<h1>2016년 1학기 데이터베이스 중간고사</h1>
</header>
<?php
	$dbc = mysqli_connect('127.0.0.1',  'root', 'apmsetup', 'spdb')
		or die('서버 연결 에러 발생');
	mysqli_query($dbc, "set names utf8;");
	
	// STATUS 오름차순 정렬
	$query = "select * from S order by STATUS asc";
	$result = mysqli_query($dbc, $query)
		or die('질의 에러 발생');
		
	if(mysqli_num_rows($result)){
		echo '<table>';
		echo '<tr><th>S#</th><th>SNAME</th><th>STATUS</th><th>CITY</th></tr>';
		while($row = mysqli_fetch_assoc($result)) {
			echo '<tr>';
			echo '<td>' . $row['snum'] . '</td>';
			echo '<td>' . $row['sname'] . '</td>';
			echo '<td>' . $row['status'] . '</td>';
			echo '<td>' . $row['city'] . '</td>';
			echo '</tr>';
		}
		echo '</table>';
	}
	mysqli_close($dbc);
?>
</body>
</html>