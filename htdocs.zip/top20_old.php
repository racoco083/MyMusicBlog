<!DOCTYPE html>
<html>
<head>
	<title>melon Top 20</title>
	<meta charset="utf-8"/>
		<style>
			header, footer {
				background-color: #eeee00;
				color: white;
				text-align: center;
				padding: 10px;
				margin: 20px;
			}
			body {
				background-color: #aaee00;
			}
			.song {
				padding: 10px;
				margin: 20px;
				text-align: center;
				
			}
			
			table {
				border-collapse: collapse;
				width: 100%;
			}
			table, tr, td, th {
				border: 2px solid green;
			}
			.song td, .grade_desc th {
				border: 2px solid lightgray;
				padding: 16px;
			}
			.song tr:nth-child(odd) {
				background-color: #eeeeee;
			}
			nav li {
				display: inline;
			}
			nav li a {
				background-color: darkgray;
				color: yellow;
				padding: 6px 100px;
				text-decoration: none;
				border-radius: 10px 0;
			}
			nav li a:hover {
				background-color: lightgray;
				color: blue;
			}
		</style>
</head>
<body>
<section class="song">
<header><h1><a href="http://localhost/melon.php"><img src="멜론.png" alt="None Picture" style="width:200px"></a></h1></header>
<nav>
		<ul>
			<?php
			if(!isset($_SESSION['id']))
				echo '<li><a href="loginform.html">로그인</a></li>';
			else
				echo '<li><a href="logout.php">로그아웃</a></li>';
			?>
			<li><a href="signup.html">회원 가입</a></li>
			<li><a href="top20.php">TOP20</a></li>
			<li><a href="#SERCH">노래 검색</a></li>
		</ul>
		</nav>
			<?php
				require_once('dbcon.php');
	
				$dbc = mysqli_connect($host, $user, $pass, $dbname)
						or die("Error Connecting to MySQL Server.");
				mysqli_query($dbc, 'set names utf8');
	
				$query = "select * from top20";
				$result = mysqli_query($dbc, $query)
						or die("Error Querying database.");
				echo '<table border=1>';
				echo '<tr><th>앨범</th><th>순위</th><th>제목</th><th>가수</th><th>좋아요</th>';
				while($row = mysqli_fetch_assoc($result)){
					echo '<tr>';
					echo '<td>' . '<img src='.$row['picture'].' alt="None Picture" style="width:100px height:200px">' . '</td><td>'
						. $row['ranking'] . '</td><td>' . $row['name'] . '</td><td>' . $row['singer']. '</td><td>' . $row['favorite'] . '</br>';
					echo '</tr>';
				}
				echo '</table>';
				mysqli_free_result($result);
				mysqli_close($dbc);
			?>
		</section>
		
		<br/>
		
		<footer>
		&copy;<a href="http://www.melon.com/index.htm">Melon</a> All Rights Reserved.
		</footer>
</body>