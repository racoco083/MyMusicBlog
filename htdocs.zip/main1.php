
<?
echo "<form  name=test-form  method=post  action=login.php>";
echo "ID: <input type=text name=id>";                 
echo "��й�ȣ: <input type=password name=pw>";    
echo "<input type=submit value=�α���>";             
?>