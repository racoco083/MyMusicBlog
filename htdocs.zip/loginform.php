<?php
	require_once("header.php");
?>

<body lang="en">
	<header class="clearfix">
		<div class="wrapper clearfix">
			
			<a href="melon.php" id="logo"><img  src="melonLogo.bmp" alt="Melon"></a>
			
			<?php
				require_once('nav.php');
			?>
		</div>
	</header>
	<div id="main">
		<div class="wrapper clearfix">
			<div class="home-block" >
				<h2 class="home-block-heading"><span>로그인</span></h2>
				<div class="one-third-thumbs clearfix" >
					<form method="post" action="login.php">
						<center>
						이메일:<br/>
						<input type="text" name="email" placeholder="Enter your e-mail"/>
						<br/>
						비밀번호:<br/>
						<input type="password" name="pass" placeholder="Enter your password"/>
						<br/>
						<br/>
						<input type="submit" value="로그인"/>
						</center>
					</form>
					
				</div>
			</div>	        	
		</div>
	</div>
	<?php
		require_once('footer.php');
	?>
				
</body>

</html>