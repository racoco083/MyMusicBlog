<?php
	require_once("session.php");
	require_once("header.php");
?>
	
	<body lang="en">
		<header class="clearfix">
		
			<!-- top widget -->
			
			<!-- ENDS top-widget -->
		
			<div class="wrapper clearfix">
				
				<a href="melon.php" id="logo"><img  src="melonLogo.bmp" alt="Melon"></a>
				
				<?php
					require_once("nav.php");
				?>
			</div>
		</header>
		<!-- MAIN -->
		<div id="main">
			<div class="wrapper clearfix">
				<!-- home-block -->
	        	<div class="home-block" >
	        		<h2 class="home-block-heading"><span>Top10</span></h2>
	        		<div class="one-third-thumbs clearfix" >
						<?php
							require_once('dbcon.php');
	
							$dbc = mysqli_connect($host, $user, $pass, $dbname)
								or die("Error Connecting to MySQL Server.");
							mysqli_query($dbc, 'set names utf8');
	
							$query = "select * from top10";
							$result = mysqli_query($dbc, $query)
									or die("Error Querying database.");
							while($row = mysqli_fetch_assoc($result)){
								echo '<figure>';
								echo '<figcaption>';
	        					echo '<strong>'.$row['name'].'</strong>';
	        					echo '<span>'.'Artist : '.$row['singer'].'</span>';
                                echo '<span>'.'♥'.$row['favorite'].'</span>';
	        					echo '<em>'.$row['date'].'</em>';
								echo '</figcaption>';
								echo '<a class="thumb"><img src='.$row['picture'].' alt="Alt text"  width="620" height="273"/></a>';
								echo '</figure>';
							}
							mysqli_free_result($result);
							mysqli_close($dbc);
						?>
	        			
	        		</div>
	        	</div>
			</div>
		</div>
		<?php
			require_once("footer.php");
		?>
					
	</body>
	
</html>