<?php
	require_once("session.php");
	require_once("header.php");
?>
	<body lang="en">
		<header class="clearfix">
			<div class="wrapper clearfix">
				
				<a href="melon.php" id="logo"><img  src="melonLogo.bmp" alt="Melon"></a>
				
				<?php
					require_once("nav.php");
				?>
			</div>
		</header>
		<!-- MAIN -->
		<div id="main">
			<div class="wrapper clearfix">
			<section class="model">
				<form name="myform" method="post" enctype="multipart/form-data">
					useremail:
					<input id="usermail" type="text" name="useremail"/>
					<input id="search" type=button value="검색"/>
					<br/>
					<br/>
				</form>
				
				<div id="refresh">새로 고침</div>
				<div id="write_review"><a href="writereviewform.php">리뷰 등록</a></div>
				<article class="review">
					<div class="img_frame">
						<img class="user_image" src="image/2015_April_1.png" alt="None Picture"/>
						<div class="user_memo"><p>ssssssssssssssssssssssssssss</p></div>
						<div class="user_info">
							<img class="user_thumbnail" src="image/2015_April_1.png" alt="User Image"/>
							<div class="user_email">a@1.com</div>
							<div class="user_date">2015년 12월 27일</div>
						</div>
					</div>
					<section class="review_reply">
						<div id="write_reply"><a href="writereplyform.php?reviewid=2">댓글 등록</a></div>
						<article class="reply">
							<div class="user_reply"><p>asdfasdfasdfasdf</p></div>
							<div class="user_info">
								<img class="user_thumbnail" src="images/2015_April_1.png" alt="User Image"/>
								<div class="user_email">a@1.com</div>
								<div class="user_date">2015년 12월 27일</div>
							</div>
						</article>
						<article class="reply">
							<div class="user_reply"><p>asasdfasdfasdf</p></div>
							<div class="user_info">
								<img class="user_thumbnail" src="image/2015_April_1.png" alt="User Image"/>
								<div class="user_email">a@a.com</div>
								<div class="user_date">2015년 12월 27일</div>
							</div>
						</article>
					</section>
				</article>
			</section>
			</div>
		</div>
		<?php
			require_once("footer.php");
		?>
					
	</body>
	
</html>