<html>
<head>
<title>PHP ����(MySQL)</title>
</head> 
<body> 

        <? 
            $link_id=mysql_connect('localhost', 'root', 'apmsetup');
            mysql_select_db('test', $link_id);
            $res = mysql_query("select * from test", $link_id);
             $row_num = mysql_num_rows($res);

            for($i=0 ;  $i< $row_num ; $i++) 
			{
            $arr =  mysql_fetch_array($res);
            echo("  $arr[name] : $arr[phone]  <br> " );
            }
         
        ?>
</body> 
</html>