<?php
	header('Content-Type: text/xml;charset=UTF-8');
	echo '<?xml version="1.0" encoding="UTF-8"?>';
?>
<top10>
<?php
	$dbc = mysqli_connect("127.0.0.1", "root", "apmsetup", "melon")
			or die("Error Connecting to MySQL Server.");
	mysqli_query($dbc, 'set names utf8');
	
	$query = "select * from top10";
	$result = mysqli_query($dbc, $query)
			or die("Error Querying database.");
			
	while($row = mysqli_fetch_assoc($result)){
		echo '<song>';
			echo '<순위>'.$row['ranking'].'</순위>';
			echo '<제목>'.$row['name'].'</제목>';
			echo '<가수>'.$row['singer'].'</가수>';
			echo '<좋아요>'.$row['favorite'].'</좋아요>';
			echo '<날짜>'.$row['date'].'</날짜>';
		echo '</song>';
	}
	
?>
</top10>