<?php
	$name = '[본인의 이름]';
	echo '<html>';
	echo '<head>';
	echo '<title>PHP 예제</title>';
	echo '<meta charset="utf-0"/>';
	echo '</head>';
	echo '<body>';
	echo '<H1>', $name, '의 홈페이지 입니다.</H1>';
	echo '만나서 반갑습니다.';
	echo date('Y년 m월 d일 H시 i분');
	echo '</body></html>';
?>