        <html> 
        <title>PHP ����(���ϰ��� �Լ�)</title> 
        <body> 
        <? 
      
print("fopen(),  fread() ���� :<br>");

        $fp = fopen("gildong/test.dat" , "r"); 
        if(!fp) { 
             echo("���Ͽ��� ����"); 
        } 
        $content = fread($fp, 50); 
        echo("$content"); 
         fclose($fp);

 print("<p>fwrite() ���� :<br>");
        $fp = fopen("gildong/test.dat" , "a"); 
        if(!fp) { 
             echo("���Ͽ��� ����"); 
        } 
        $str ="\n���̻�,123123123"; 
        fwrite($fp, $str); 
        fclose($fp);
	$fp = fopen("gildong/test.dat" , "r"); 
	$content = fread($fp, filesize("gildong/test.dat"));
 	echo("$content"); 
	fclose($fp);

 print("<p>fgets() ���� :<br>");
	$fp = fopen("gildong/test.dat" , "r"); 
        while(!feof($fp)) { 
            $line = fgets($fp, 2000); 
            print("$line <br>"); 
         } 
  	fclose($fp);

 print("<p>file() ���� :<br>");
        $file_name = "gildong/test.dat"; 
        $line = file($file_name); 
        while(list($key, $val) = each($line)) { 
             echo("$val<br>"); 
        }


        ?> 
        </body> 
        </html>